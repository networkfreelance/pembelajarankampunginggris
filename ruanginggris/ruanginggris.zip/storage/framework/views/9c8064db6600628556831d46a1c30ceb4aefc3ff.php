<?php $__env->startSection('konten'); ?>
<section class="content-header">
  <h1>
    Dashboard
  </h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
    <li class="active">Dashboard</li>
  </ol>
</section>

<!-- Main content -->
<section class="content">

  <div class="row">
    <?php echo e(Session::get('id')); ?>

        <div class="col-lg-3 col-xs-6">
          <!-- small box -->

          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php echo e(count($jumlah_materi)); ?></h3>

              <p>Total materi</p>
            </div>
            <div class="icon">
              <i class="fa fa-file-text"></i>
            </div>

          </div>
        </div>

        <!-- ./col -->
  </div>

</section>
<!-- /.content -->
<?php $__env->stopSection(); ?>
<!-- DataTables -->

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pembelajarankampunginggris\ruanginggris\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>