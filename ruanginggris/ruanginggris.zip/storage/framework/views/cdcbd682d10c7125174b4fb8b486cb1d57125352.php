<?php $__env->startSection('konten'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
  <h1>
    User Profile
  </h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
    <li class="active">User profil</li>
  </ol>
</section>

<!-- Main content -->
<section class="content">
<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="row">
    <div class="col-md-3">

      <!-- Profile Image -->
      <div class="box box-primary">
        <div class="box-body box-profile">
          <img class="profile-user-img img-responsive img-circle" src="<?php echo e(url('/foto_profil/avatar.png')); ?>" alt="User profile picture">

          <h3 class="profile-username text-center"><?php echo e($p->nama); ?></h3>

          <ul class="list-group list-group-unbordered">
            <li class="list-group-item">
              <b>Total Materi</b> <a class="pull-right">
                <?php
                $no=0;
                ?>
                <?php $__currentLoopData = $paket_materi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php $__currentLoopData = $paket_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php
                    if($pm->nama_paket==$ps->nama_paket){
                      $no++
                  ?>
                      <?php echo e($no); ?>

                  <?php
                    }
                  ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </a>
            </li>
            <li class="list-group-item">
              <b>Jumlah Paket</b> <a class="pull-right"><?php echo e(count($total_paket)); ?></a>
            </li>

          </ul>


        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->

      <!-- About Me Box -->
      <div class="box box-primary">
        <div class="box-header with-border">
          <h3 class="box-title">About Me</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <strong><i class="fa fa-book margin-r-5"></i> Nama</strong>

          <p class="text-muted">
            <?php echo e($p->nama); ?>

          </p>

          <hr>

          <strong><i class="fa fa-book margin-r-5"></i> Username</strong>

          <p class="text-muted"><?php echo e($p->username); ?></p>

          <hr>

          <strong><i class="fa fa-book margin-r-5"></i> Email</strong>

          <p><?php echo e($p->email); ?></p>

          <hr>

          <strong><i class="fa fa-book margin-r-5"></i> Alamat</strong>

          <p><?php echo e($p->alamat); ?></p>

          <hr>

          <strong><i class="fa fa-book margin-r-5"></i> Telp</strong>

          <p><?php echo e($p->telp); ?></p>

        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
    <div class="col-md-9">
      <div class="box box-primary">
        <div class="box-header with-border">
          <h3 class="box-title">About Me</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <form class="form-horizontal" action="<?php echo e(url('/pesertaprofil/update_aksi')); ?>" method="post" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="id" value="<?php echo e($p->id); ?>"> <br/>
            <div class="form-group">
              <label for="inputName" class="col-sm-2 control-label">Nama</label>

              <div class="col-sm-10">
                <input type="text" name="nama" value="<?php echo e($p->nama); ?>" class="form-control" id="inputName" placeholder="Nama">
              </div>
            </div>
            <div class="form-group">
              <label for="inputName" class="col-sm-2 control-label">Username</label>

              <div class="col-sm-10">
                <input type="text" name="username" value="<?php echo e($p->username); ?>" class="form-control" id="inputName" placeholder="Username">
              </div>
            </div>
            <div class="form-group">
              <label for="inputEmail" class="col-sm-2 control-label">Email</label>

              <div class="col-sm-10">
                <input type="email" name="email" value="<?php echo e($p->email); ?>" class="form-control" id="inputEmail" placeholder="Email">
              </div>
            </div>

            <div class="form-group">
              <label for="inputExperience" class="col-sm-2 control-label">Alamat</label>

              <div class="col-sm-10">
                <textarea class="form-control" name="alamat"  id="inputExperience" placeholder="Alamat"><?php echo e($p->alamat); ?></textarea>
              </div>
            </div>

            <div class="form-group">
              <label for="inputEmail" class="col-sm-2 control-label">Telp</label>

              <div class="col-sm-10">
                <input type="text" name="telp" value="<?php echo e($p->telp); ?>" class="form-control" id="inputEmail" placeholder="Telp">
              </div>
            </div>


            <div class="form-group">
              <div class="col-sm-offset-2 col-sm-10">
                <button type="submit" class="btn btn-danger">Update</button>
              </div>
            </div>
          </form>
        </div>
      </div>


      <!-- /.nav-tabs-custom -->
    </div>
    <!-- /.col -->

  </div>
  <!-- /.row -->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>
<!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pembelajarankampunginggris\ruanginggris\resources\views/peserta/profil.blade.php ENDPATH**/ ?>