<?php $__env->startSection('konten'); ?>
<section class="content-header">
  <h1>
    Admin
  </h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
    <li class="active">admin</li>
  </ol>
</section>

<!-- Main content -->
<section class="content">
<div class="row">
  <div class="col-md-6">
    <!-- <a href="<?php echo e(url('adminadmin/tambah')); ?>" class="btn btn-success btn-lg pull-right">Tambah admin</a> -->
    <form action="<?php echo e(url('admin/import')); ?>" method="POST" name="importform" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <input type="file" name="file" class="form-control">
        <br>
        <button type="submit" class="btn btn-success">Import Bulk Data</button>
        <a class="btn btn-warning" href="<?php echo e(route('export')); ?>">Export Bulk Data</a>
    </form>
  </div>
  <div class="col-md-6">
    <div class="box box-primary">
      <div class="box-header">
        <h3 class="box-title">Navigasi</h3>
      </div>
      <div class="box-body">
        <!-- Date -->
        <a class="btn btn-danger" href="<?php echo e(url('admin/tambah')); ?>">Tambah User Admin</a>
      </div>
      <!-- /.box-body -->
    </div>
  </div>
  <div class="col-md-12">
  <!-- Default box -->
  <div class="box">
    <div class="box-header with-border">
      <h3 class="box-title">Daftar admin</h3>

      <div class="box-tools pull-right">
        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip"
                title="Collapse">
          <i class="fa fa-minus"></i></button>
        <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
          <i class="fa fa-times"></i></button>
      </div>
    </div>
    <div class="box-body">
            <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Nama</th>
                  <th>Username</th>
                  <th>Email</th>
                  <th>Password</th>
                  <th>Alamat</th>
                  <th>Kota</th>
                  <th>Telp</th>
                  <th>Level</th>
                  <th>Aksi</th>
                </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              		<tr>

              			<td><?php echo e($p->nama); ?></td>
              			<td><?php echo e($p->username); ?></td>
                    <td><?php echo e($p->email); ?></td>
                    <td><?php echo e($p->password_asli); ?></td>
                    <td><?php echo e($p->alamat); ?></td>
                    <td><?php echo e($p->kota); ?></td>
                    <td><?php echo e($p->telp); ?></td>
                    <td><?php echo e($p->level); ?></td>
              			<td>
              				<a href="<?php echo e(url('admin/edit/'.$p->id)); ?>">Edit</a>
              				|
              				<a href="<?php echo e(url('/admin/hapus_aksi/'.$p->id)); ?>">Hapus</a>
              			</td>
              		</tr>
              		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                <tr>
                  <th>Nama</th>
                  <th>Username</th>
                  <th>Email</th>
                  <th>Password</th>
                  <th>Alamat</th>
                  <th>Kota</th>
                  <th>Telp</th>
                  <th>Level</th>
                  <th>Aksi</th>
                </tr>
                </tfoot>
              </table>
    </div>
    <!-- /.box-body -->
    <!-- /.box-footer-->
  </div>
  <!-- /.box -->
  </div>
</div>
</section>
<!-- /.content -->
<?php $__env->stopSection(); ?>
<!-- DataTables -->

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pembelajarankampunginggris\ruanginggris\resources\views/admin/admin.blade.php ENDPATH**/ ?>