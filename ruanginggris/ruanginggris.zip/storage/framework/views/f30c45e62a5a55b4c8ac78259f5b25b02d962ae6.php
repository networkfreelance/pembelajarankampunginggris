<?php $__env->startSection('konten'); ?>
<!-- Content Header (Page header) -->
<style>
video {
  width: 100%    !important;
  height: auto   !important;
}
</style>
<section class="content-header">
  <h1>
    Preview Materi
  </h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
    <li class="active">Preview Materi</li>
  </ol>
</section>

<!-- Main content -->
<section class="content">

  <div class="row">
<?php $__currentLoopData = $materi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <!-- /.col -->
    <div class="col-md-8">
      <div class="col-md-12">
          <!-- Box Comment -->
          <div class="box box-widget">
            <div class="box-header with-border">
              <div class="user-block">
                <img class="img-circle" src="<?php echo e(url('/foto_profil/avatar.png')); ?>" alt="User Image">
                <span class="username"><a href="#">Judul Materi : <?php echo e($p->nama_materi); ?>.</a></span>
                <span class="description">Shared publicly <?php echo e($p->tanggal_publikasi); ?></span>
              </div>
              <!-- /.user-block -->
              <!-- /.box-tools -->
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <video width="320" height="240" controls>
                    <source src="<?php echo e(url('/video/'.$p->video)); ?>" type="video/mp4">
                  Your browser does not support the video tag.
              </video>
              <hr>
              <p><?php echo e($p->konten); ?></p>

            </div>
            <!-- /.box-body -->

            <!-- /.box-footer -->
            <div class="box-footer">

            </div>
            <!-- /.box-footer -->
          </div>
          <!-- /.box -->
        </div>


      <!-- /.nav-tabs-custom -->
    </div>
    <!-- /.col -->
    <div class="col-md-4">
      <a href="<?php echo e(url('/pesertakelas')); ?>" class="btn btn-block btn-primary btn-lg">Back - Kembali ke Daftar Materi</a>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </div>
  <!-- /.row -->
</section>
<!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pembelajarankampunginggris\ruanginggris\resources\views/peserta/preview_materi.blade.php ENDPATH**/ ?>