<?php $__env->startSection('konten'); ?>
    <!-- Main Section -->
    <section class="main-section">
        <!-- Add Your Content Inside -->
        <div class="content">
            <!-- Remove This Before You Start -->
            <h1>Anak IT -  Tutorial Login, Register, Validasi dengan Laravel 5.4</h1>
            <p>Hallo, <?php echo e(Session::get('name')); ?>. Apakabar?</p>
            <p>Level, <?php echo e(Session::get('level')); ?></p>
            <p>ID, <?php echo e(Session::get('id')); ?></p>
            <?php
            $tanggal=date('Y-m-d');
            $pinjam            = date("Y-m-d");
            $tujuh_hari        = mktime(0,0,0,date("n"),date("j")+90,date("Y"));
            echo 'expired login : '.$kembali      = date("Y-m-d", $tujuh_hari);
            ?>
            <h2>* Email kamu : <?php echo e(Session::get('email')); ?></h2>
            <h2>* Status Login : <?php echo e(Session::get('login')); ?></h2>
            <a href="<?php echo e(url('/logoutku')); ?>" class="btn btn-primary btn-lg">Logout</a>

        </div>
        <!-- /.content -->
    </section>
    <!-- /.main-section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pembelajarankampunginggris\ruanginggris\resources\views/user.blade.php ENDPATH**/ ?>