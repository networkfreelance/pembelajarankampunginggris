
<!-- Left side column. contains the sidebar -->

<aside class="main-sidebar">
  <!-- sidebar: style can be found in sidebar.less -->
  <section class="sidebar">
    <!-- sidebar menu: : style can be found in sidebar.less -->
    <ul class="sidebar-menu" data-widget="tree">
      <li class="header">MAIN NAVIGATION</li>
      <li><a href="<?php echo e(url('admindashboard')); ?>"><i class="fa fa-book"></i> <span>Dashboard</span></a></li>
      <li><a href="<?php echo e(url('adminblog')); ?>"><i class="fa fa-book"></i> <span>Profil Peserta</span></a></li>
      <li><a href="<?php echo e(url('adminslide')); ?>"><i class="fa fa-book"></i> <span>Ruang Belajar</span></a></li>
      <li><a href="<?php echo e(url('adminvendor')); ?>"><i class="fa fa-book"></i> <span>User Admin</span></a></li>
    </ul>
  </section>
  <!-- /.sidebar -->
</aside>
<?php /**PATH D:\xampp\htdocs\pembelajarankampunginggris\ruanginggris\resources\views/sidebar_member.blade.php ENDPATH**/ ?>