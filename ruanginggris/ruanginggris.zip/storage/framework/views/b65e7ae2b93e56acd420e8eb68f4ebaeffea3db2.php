<?php $__env->startSection('konten'); ?>
<section class="content-header">
  <h1>
    Tambah Materi
  </h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
    <li class="active"> Materi</li>
    <li class="active"> Lihat Materi</li>
    <li class="active"> Tambah Materi</li>
  </ol>
</section>

<!-- Main content -->
<section class="content">
  <div class="row">
    <div class="col-md-12">
      <!-- general form elements -->
      <div class="box box-primary">
        <!-- /.box-header -->
        <!-- form start -->

        <form method="post" action="<?php echo e(url('/adminpaket/tambah_aksi')); ?>" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <!-- <?php echo e(csrf_token()); ?> -->
          <div class="box-body">
            <div class="form-group">
              <label for="exampleInputEmail1">Pilih Paket</label>
                  <select class="form-control" name="nama_paket">
                    <?php $__currentLoopData = $paket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <option name="<?php echo e($p->nama_paket); ?>"><?php echo e($p->nama_paket); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </select>
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Buku</label>
              <input type="text" name="buku" class="form-control" id="exampleInputPassword1" placeholder="Buku" required="">
            </div>
          </div>
          <!-- /.box-body -->
          <div id="success"></div>
          <div class="box-footer">
            <button type="submit" name="upload" class="btn btn-primary">Submit</button>
          </div>
        </form>
      </div>
      </div>
    </div>
  </section>




  <!-- /.content -->
  <?php $__env->stopSection(); ?>
  <!-- DataTables -->

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pembelajarankampunginggris\ruanginggris\resources\views/admin/tambah_paket.blade.php ENDPATH**/ ?>